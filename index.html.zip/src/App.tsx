import { useState, useEffect, useRef } from "react";

/* ─── SVG Icons ──────────────────────────────────────────────── */
const IconLeaf = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
    <path d="M2 22c0 0 5-10 20-10C22 22 2 22 2 22z"/>
    <path d="M12 12L2 22"/>
  </svg>
);
const IconSun = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
    <circle cx="12" cy="12" r="5"/>
    <line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
    <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
  </svg>
);
const IconDroplet = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
    <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>
  </svg>
);
const IconSprout = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
    <path d="M7 20h10M10 20c5.5-2.5.8-6.4 3-10"/>
    <path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-2-3.7 2.7-.5 3.4.4 4.5.3z"/>
    <path d="M14.1 6c-.9 2.5.7 5.6 2.7 6.5-.1-2.5-1.2-5.2-2.7-6.5z"/>
  </svg>
);
const IconTractor = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
    <circle cx="7" cy="17" r="2.5"/><circle cx="17.5" cy="17" r="1.5"/>
    <path d="M5 17H3v-3l2-5h10l2 8H5z"/><path d="M13 12V7h3l3 5"/>
  </svg>
);
const IconGlobe = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
    <circle cx="12" cy="12" r="10"/>
    <path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
  </svg>
);
const IconShield = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    <path d="M9 12l2 2 4-4"/>
  </svg>
);
const IconTrend = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/>
    <polyline points="17 6 23 6 23 12"/>
  </svg>
);
const IconRecycle = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="w-full h-full">
    <polyline points="1.5 2 1.5 8 7.5 8"/>
    <path d="M2 13a10 10 0 1 0 .5-4.5L1.5 8"/>
  </svg>
);
const IconMenu = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{width:24,height:24}}>
    <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
  </svg>
);
const IconClose = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{width:24,height:24}}>
    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
);
const IconArrow = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{width:18,height:18,display:'inline',marginLeft:6}}>
    <line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>
  </svg>
);
const IconCheck = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{width:18,height:18,flexShrink:0}}>
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);

/* ─── Decorative Background SVG ────────────────────────────────── */
const BgCircles = () => (
  <div style={{position:'absolute',inset:0,overflow:'hidden',pointerEvents:'none'}}>
    <div style={{
      position:'absolute',top:'-200px',right:'-200px',width:'700px',height:'700px',
      borderRadius:'50%',border:'1px solid rgba(126,184,63,.07)',
    }}/>
    <div style={{
      position:'absolute',top:'-100px',right:'-100px',width:'500px',height:'500px',
      borderRadius:'50%',border:'1px solid rgba(126,184,63,.05)',
    }}/>
    <div style={{
      position:'absolute',bottom:'-300px',left:'-200px',width:'800px',height:'800px',
      borderRadius:'50%',border:'1px solid rgba(201,162,39,.04)',
    }}/>
  </div>
);

/* ─── Animated Number ────────────────────────────────────────── */
function AnimNum({ target, suffix = "", prefix = "" }: { target: number; suffix?: string; prefix?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !started.current) {
        started.current = true;
        const dur = 1800, steps = 60, inc = target / steps;
        let cur = 0;
        const t = setInterval(() => {
          cur += inc;
          if (cur >= target) { setVal(target); clearInterval(t); }
          else setVal(Math.floor(cur));
        }, dur / steps);
      }
    }, { threshold: 0.3 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [target]);
  return <span ref={ref}>{prefix}{val.toLocaleString("pt-BR")}{suffix}</span>;
}

/* ─── Progress Bar ───────────────────────────────────────────── */
function ProgressBar({ pct, label }: { pct: number; label: string }) {
  const [active, setActive] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setActive(true); }, { threshold: 0.3 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return (
    <div ref={ref} style={{marginBottom:20}}>
      <div style={{display:'flex',justifyContent:'space-between',marginBottom:8,fontSize:14,color:'rgba(245,240,232,.75)'}}>
        <span>{label}</span><span style={{color:'#7eb83f',fontWeight:700}}>{pct}%</span>
      </div>
      <div className="progress-track">
        <div className="progress-fill" style={{width: active ? `${pct}%` : '0%'}}/>
      </div>
    </div>
  );
}

/* ─── Navbar ─────────────────────────────────────────────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);
  const navBg = scrolled
    ? "rgba(10,20,12,0.95)"
    : "transparent";
  const links = ["Início","Pilares","Dados","Práticas","Manifesto","Contato"];
  const scroll = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setOpen(false);
  };
  const ids = ["inicio","pilares","dados","praticas","manifesto","contato"];
  return (
    <nav style={{
      position:'fixed',top:0,left:0,right:0,zIndex:1000,
      background:navBg, transition:'background .4s ease',
    }} className="nav-glass">
      <div style={{maxWidth:1200,margin:'0 auto',padding:'0 24px',display:'flex',alignItems:'center',justifyContent:'space-between',height:70}}>
        {/* Logo */}
        <div style={{display:'flex',alignItems:'center',gap:10,cursor:'pointer'}} onClick={() => scroll('inicio')}>
          <div style={{width:38,height:38,display:'flex',alignItems:'center',justifyContent:'center',
            background:'linear-gradient(135deg,#1a5c2a,#7eb83f)',borderRadius:6,padding:7,color:'#f5f0e8'}}>
            <IconLeaf/>
          </div>
          <div>
            <div style={{fontWeight:900,fontSize:16,letterSpacing:2,textTransform:'uppercase',lineHeight:1}}>
              <span className="text-grad-verde">AGRO</span>
              <span style={{color:'#f5f0e8'}}> FORTE</span>
            </div>
            <div style={{fontSize:9,letterSpacing:3,color:'rgba(245,240,232,.5)',textTransform:'uppercase'}}>Futuro Sustentável</div>
          </div>
        </div>
        {/* Desktop links */}
        <div style={{display:'flex',gap:32,alignItems:'center'}} className="hidden-mobile">
          {links.map((l,i) => (
            <button key={l} onClick={() => scroll(ids[i])} style={{
              background:'none',border:'none',color:'rgba(245,240,232,.75)',cursor:'pointer',
              fontSize:13,letterSpacing:1,textTransform:'uppercase',fontWeight:600,
              transition:'color .2s', padding:'4px 0',
            }}
            onMouseEnter={e => (e.currentTarget.style.color='#7eb83f')}
            onMouseLeave={e => (e.currentTarget.style.color='rgba(245,240,232,.75)')}
            >{l}</button>
          ))}
        </div>
        <button onClick={() => scroll('contato')} className="btn-verde hidden-mobile" style={{padding:'10px 22px',fontSize:12}}>
          Junte-se
        </button>
        {/* Mobile hamburger */}
        <button onClick={() => setOpen(!open)} style={{background:'none',border:'none',color:'#f5f0e8',cursor:'pointer',display:'none'}} className="show-mobile">
          {open ? <IconClose/> : <IconMenu/>}
        </button>
      </div>
      {/* Mobile menu */}
      {open && (
        <div style={{background:'rgba(10,20,12,0.98)',padding:'20px 24px',display:'flex',flexDirection:'column',gap:12}}>
          {links.map((l,i) => (
            <button key={l} onClick={() => scroll(ids[i])} style={{
              background:'none',border:'none',color:'rgba(245,240,232,.8)',cursor:'pointer',
              fontSize:15,textAlign:'left',padding:'8px 0',letterSpacing:1,
              borderBottom:'1px solid rgba(126,184,63,.1)',fontWeight:600,
            }}>{l}</button>
          ))}
        </div>
      )}
      <style>{`
        @media (max-width:768px) {
          .hidden-mobile { display:none !important; }
          .show-mobile { display:flex !important; }
        }
        @media (min-width:769px) { .show-mobile { display:none !important; } }
      `}</style>
    </nav>
  );
}

/* ─── Hero ───────────────────────────────────────────────────── */
function Hero() {
  return (
    <section id="inicio" className="hero-bg" style={{minHeight:'100vh',display:'flex',alignItems:'center',position:'relative',overflow:'hidden',paddingTop:80}}>
      <BgCircles/>
      {/* Decorative leaf SVG */}
      <div style={{position:'absolute',right:'-60px',top:'50%',transform:'translateY(-50%)',width:'520px',height:'520px',opacity:.04}}>
        <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
          <path fill="#7eb83f" d="M100,10 C140,10 180,50 180,100 C180,150 140,180 100,180 C60,180 10,150 20,80 C30,20 60,10 100,10 Z"/>
        </svg>
      </div>
      <div style={{
        position:'absolute',right:'8%',bottom:'20%',width:'300px',height:'300px',opacity:.06,
      }} className="anim-spin-slow">
        <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
          {[0,45,90,135,180,225,270,315].map(a => (
            <line key={a} x1="50" y1="50" x2={50+44*Math.cos(a*Math.PI/180)} y2={50+44*Math.sin(a*Math.PI/180)}
              stroke="#7eb83f" strokeWidth="1"/>
          ))}
          <circle cx="50" cy="50" r="8" fill="#7eb83f"/>
          {[0,45,90,135,180,225,270,315].map(a => (
            <circle key={a} cx={50+44*Math.cos(a*Math.PI/180)} cy={50+44*Math.sin(a*Math.PI/180)} r="4" fill="#c9a227"/>
          ))}
        </svg>
      </div>

      <div style={{maxWidth:1200,margin:'0 auto',padding:'80px 24px',width:'100%'}}>
        <div style={{maxWidth:720}}>
          {/* Badge */}
          <div className="anim-fade-up" style={{
            display:'inline-flex',alignItems:'center',gap:8,
            border:'1px solid rgba(126,184,63,.35)',borderRadius:100,
            padding:'6px 16px',marginBottom:32,
          }}>
            <div style={{width:8,height:8,borderRadius:'50%',background:'#7eb83f'}} className="anim-glow"/>
            <span style={{fontSize:12,letterSpacing:2,textTransform:'uppercase',color:'#7eb83f',fontWeight:700}}>
              O Agro que Cuida da Terra
            </span>
          </div>

          <h1 className="anim-fade-up d2" style={{
            fontSize:'clamp(42px,7vw,88px)',fontWeight:900,lineHeight:1.0,
            marginBottom:24,letterSpacing:'-2px',
          }}>
            <span style={{color:'#f5f0e8'}}>AGRO</span>{' '}
            <span className="text-grad-verde">FORTE</span>
            <br/>
            <span style={{color:'#f5f0e8',opacity:.9}}>FUTURO</span>{' '}
            <span className="text-grad-gold">VERDE</span>
          </h1>

          <p className="anim-fade-up d3" style={{
            fontSize:'clamp(16px,2vw,20px)',lineHeight:1.75,color:'rgba(245,240,232,.72)',
            marginBottom:44,maxWidth:560,
          }}>
            O equilíbrio entre <strong style={{color:'#a8d55a'}}>alta produção</strong> e{' '}
            <strong style={{color:'#c9a227'}}>preservação ambiental</strong> não é utopia —
            é o caminho que o agro brasileiro está construindo hoje.
          </p>

          <div className="anim-fade-up d4" style={{display:'flex',gap:16,flexWrap:'wrap'}}>
            <a href="#pilares" className="btn-verde" onClick={e=>{e.preventDefault();document.getElementById('pilares')?.scrollIntoView({behavior:'smooth'})}}>
              Explorar Pilares <IconArrow/>
            </a>
            <a href="#manifesto" className="btn-ghost" onClick={e=>{e.preventDefault();document.getElementById('manifesto')?.scrollIntoView({behavior:'smooth'})}}>
              Nosso Manifesto
            </a>
          </div>

          {/* Quick stats */}
          <div className="anim-fade-up d5" style={{
            display:'flex',gap:40,marginTop:64,flexWrap:'wrap',
          }}>
            {[
              {n:'#1', label:'Exportador de alimentos'},
              {n:'215M', label:'Hectares conservados'},
              {n:'37%', label:'Renovável na matriz'},
            ].map(s => (
              <div key={s.label}>
                <div style={{fontSize:'clamp(22px,3vw,32px)',fontWeight:900,color:'#7eb83f',lineHeight:1}}>{s.n}</div>
                <div style={{fontSize:12,color:'rgba(245,240,232,.55)',marginTop:4,letterSpacing:.5}}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div style={{
        position:'absolute',bottom:32,left:'50%',transform:'translateX(-50%)',
        display:'flex',flexDirection:'column',alignItems:'center',gap:8,
      }} className="anim-float">
        <div style={{fontSize:10,letterSpacing:3,textTransform:'uppercase',color:'rgba(245,240,232,.35)'}}>Rolar</div>
        <div style={{width:1,height:40,background:'linear-gradient(180deg,rgba(126,184,63,.6),transparent)'}}/>
      </div>
    </section>
  );
}

/* ─── Pilares ─────────────────────────────────────────────────── */
const pilares = [
  {
    icon: <IconTractor/>, color:'#7eb83f', label:'Produção',
    title:'Alta Produtividade',
    desc:'Tecnologia de ponta, genética avançada e manejo preciso que colocam o Brasil entre os maiores produtores globais de alimentos.',
    items:['Agricultura de precisão','Biotecnologia avançada','Mecanização inteligente'],
  },
  {
    icon: <IconLeaf/>, color:'#a8d55a', label:'Sustentabilidade',
    title:'Terra Que Dura',
    desc:'Práticas que regeneram o solo, conservam nascentes e preservam biomas enquanto garantem colheitas abundantes para as próximas gerações.',
    items:['Plantio direto','Recuperação de pastagens','Reflorestamento produtivo'],
  },
  {
    icon: <IconGlobe/>, color:'#c9a227', label:'Inovação',
    title:'Tecnologia Verde',
    desc:'Drones, satélites, IA e sensores inteligentes otimizando cada metro quadrado — produzindo mais com muito menos impacto.',
    items:['AgTech & IoT rural','Big Data agronômico','Energia renovável no campo'],
  },
  {
    icon: <IconShield/>, color:'#e8c84a', label:'Equilíbrio',
    title:'Harmonia Real',
    desc:'O equilíbrio entre produção e natureza não é escolha — é estratégia. Quem protege o solo protege o futuro do negócio.',
    items:['Código Florestal cumprido','Rastreabilidade total','Certificação ESG rural'],
  },
];

function Pilares() {
  return (
    <section id="pilares" className="bg-dark2" style={{padding:'120px 0',position:'relative',overflow:'hidden'}}>
      <div style={{maxWidth:1200,margin:'0 auto',padding:'0 24px'}}>
        <div style={{textAlign:'center',marginBottom:72}}>
          <div className="anim-fade-up" style={{display:'inline-block'}}>
            <div className="divider" style={{margin:'0 auto 20px'}}/>
          </div>
          <h2 className="anim-fade-up d1" style={{fontSize:'clamp(32px,4vw,56px)',fontWeight:900,marginBottom:16,letterSpacing:'-1px'}}>
            Os <span className="text-grad-verde">4 Pilares</span> do{' '}
            <span className="text-grad-gold">Agro Sustentável</span>
          </h2>
          <p className="anim-fade-up d2" style={{color:'rgba(245,240,232,.6)',maxWidth:540,margin:'0 auto',fontSize:17,lineHeight:1.7}}>
            A força do campo brasileiro nasce do equilíbrio entre tradição, ciência e responsabilidade ambiental.
          </p>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:24}}>
          {pilares.map((p, i) => (
            <div key={p.label} className={`card-lift glow-border anim-fade-up d${i+2}`}
              style={{
                background:'rgba(255,255,255,.03)',borderRadius:12,padding:36,
                position:'relative',overflow:'hidden',
              }}>
              {/* Top accent */}
              <div style={{position:'absolute',top:0,left:0,right:0,height:3,background:`linear-gradient(90deg,${p.color},transparent)`}}/>
              {/* Icon */}
              <div style={{
                width:56,height:56,borderRadius:12,
                background:`rgba(${p.color==='#7eb83f'?'126,184,63':p.color==='#a8d55a'?'168,213,90':p.color==='#c9a227'?'201,162,39':'232,200,74'},.15)`,
                color:p.color,padding:13,marginBottom:20,
                border:`1px solid ${p.color}30`,
              }}>
                {p.icon}
              </div>
              <div style={{fontSize:11,letterSpacing:2,textTransform:'uppercase',color:p.color,fontWeight:700,marginBottom:8}}>{p.label}</div>
              <h3 style={{fontSize:22,fontWeight:800,marginBottom:12,letterSpacing:'-0.5px'}}>{p.title}</h3>
              <p style={{color:'rgba(245,240,232,.6)',fontSize:14,lineHeight:1.7,marginBottom:20}}>{p.desc}</p>
              <ul style={{listStyle:'none',display:'flex',flexDirection:'column',gap:8}}>
                {p.items.map(it => (
                  <li key={it} style={{display:'flex',alignItems:'center',gap:10,fontSize:13,color:'rgba(245,240,232,.75)'}}>
                    <div style={{color:p.color,flexShrink:0}}><IconCheck/></div>
                    {it}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Dados / Stats ────────────────────────────────────────────── */
const stats = [
  {val:340, suffix:'M t', label:'Produção de grãos anual', icon:<IconTrend/>, color:'#7eb83f'},
  {val:215, suffix:'M ha', label:'Área de vegetação nativa conservada', icon:<IconLeaf/>, color:'#a8d55a'},
  {val:37,  suffix:'%', label:'Matriz energética renovável', icon:<IconSun/>, color:'#c9a227'},
  {val:180, suffix:'países', label:'Destino das exportações brasileiras', icon:<IconGlobe/>, color:'#e8c84a'},
];

const progressData = [
  {label:'Redução do desmatamento (últimos 5 anos)', pct:63},
  {label:'Propriedades com Cadastro Ambiental Rural', pct:78},
  {label:'Adoção de plantio direto em lavouras', pct:71},
  {label:'Energia renovável no agronegócio', pct:85},
  {label:'Rastreabilidade na pecuária bovina', pct:56},
];

function Dados() {
  return (
    <section id="dados" className="bg-dark3" style={{padding:'120px 0',position:'relative',overflow:'hidden'}}>
      <BgCircles/>
      <div style={{maxWidth:1200,margin:'0 auto',padding:'0 24px'}}>
        <div style={{textAlign:'center',marginBottom:72}}>
          <div className="divider" style={{margin:'0 auto 20px'}}/>
          <h2 className="anim-fade-up" style={{fontSize:'clamp(28px,4vw,52px)',fontWeight:900,marginBottom:16,letterSpacing:'-1px'}}>
            <span className="text-grad-verde">Números</span> que Provam
          </h2>
          <p className="anim-fade-up d1" style={{color:'rgba(245,240,232,.6)',maxWidth:500,margin:'0 auto',fontSize:16}}>
            O agro brasileiro sustentável não é slogan — são décadas de resultados mensuráveis.
          </p>
        </div>

        {/* Big stats */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))',gap:20,marginBottom:72}}>
          {stats.map((s,i) => (
            <div key={s.label} className={`card-lift glow-border anim-scale d${i+1}`}
              style={{
                background:'rgba(255,255,255,.03)',borderRadius:12,padding:32,textAlign:'center',
                border:'1px solid rgba(126,184,63,.12)',
              }}>
              <div style={{width:48,height:48,color:s.color,margin:'0 auto 16px',opacity:.9}}>{s.icon}</div>
              <div style={{fontSize:'clamp(32px,4vw,52px)',fontWeight:900,color:s.color,lineHeight:1,marginBottom:8}}>
                <AnimNum target={s.val} suffix={s.suffix}/>
              </div>
              <div style={{fontSize:13,color:'rgba(245,240,232,.6)',lineHeight:1.4}}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Progress bars + text */}
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:60,alignItems:'start'}} className="dados-grid">
          <div className="anim-slide-l">
            <h3 style={{fontSize:28,fontWeight:800,marginBottom:8}}>
              Indicadores de <span className="text-grad-verde">Progresso</span>
            </h3>
            <p style={{color:'rgba(245,240,232,.6)',marginBottom:36,fontSize:15,lineHeight:1.7}}>
              Metas ambientais e produtivas avançando juntas ao longo dos últimos anos.
            </p>
            {progressData.map(p => <ProgressBar key={p.label} pct={p.pct} label={p.label}/>)}
          </div>
          <div className="anim-slide-r">
            <div style={{
              background:'rgba(126,184,63,.06)',borderRadius:16,padding:36,
              border:'1px solid rgba(126,184,63,.15)',
            }}>
              <h3 style={{fontSize:22,fontWeight:800,marginBottom:20,color:'#a8d55a'}}>Por que o Brasil lidera?</h3>
              {[
                {t:'Diversidade climática', d:'Tropical, subtropical e temperado — produzimos o ano inteiro.'},
                {t:'Pesquisa de ponta', d:'Embrapa e universidades desenvolvem tecnologias tropicais únicas.'},
                {t:'Escala com eficiência', d:'Maior produtor que usa menos água e insumos por tonelada produzida.'},
                {t:'Legislação ambiental', d:'Código Florestal exige preservação de 20% a 80% em propriedades rurais.'},
              ].map(it => (
                <div key={it.t} style={{marginBottom:20,paddingBottom:20,borderBottom:'1px solid rgba(126,184,63,.1)'}}>
                  <div style={{fontWeight:700,color:'#f5f0e8',marginBottom:4,fontSize:15}}>{it.t}</div>
                  <div style={{color:'rgba(245,240,232,.55)',fontSize:13,lineHeight:1.6}}>{it.d}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <style>{`
        @media (max-width:768px) { .dados-grid { grid-template-columns:1fr !important; } }
      `}</style>
    </section>
  );
}

/* ─── Práticas Sustentáveis ──────────────────────────────────── */
const praticas = [
  {
    icon:<IconSprout/>, color:'#7eb83f',
    title:'Plantio Direto',
    desc:'Técnica que elimina o revolvimento do solo, conserva umidade, reduz erosão e sequestra carbono na matéria orgânica.',
    tag:'Solo & Carbono',
  },
  {
    icon:<IconDroplet/>, color:'#4a9fd4',
    title:'Irrigação Inteligente',
    desc:'Sensores de umidade e IA calculam a quantidade exata de água, reduzindo consumo em até 40% sem perder produtividade.',
    tag:'Água & Eficiência',
  },
  {
    icon:<IconRecycle/>, color:'#c9a227',
    title:'Economia Circular',
    desc:'Resíduos agropecuários viram biogás, adubo orgânico e biomassa energética — fechando o ciclo produtivo com zero desperdício.',
    tag:'Energia & Resíduos',
  },
  {
    icon:<IconLeaf/>, color:'#a8d55a',
    title:'Integração Lavoura-Floresta',
    desc:'Sistemas integrados que combinam culturas, pastagem e floresta no mesmo espaço, recuperando o solo e gerando renda extra.',
    tag:'Biodiversidade',
  },
  {
    icon:<IconSun/>, color:'#e8c84a',
    title:'Energia Solar no Campo',
    desc:'Painéis fotovoltaicos em propriedades rurais reduzem custos operacionais e tornam a fazenda energeticamente autossuficiente.',
    tag:'Energias Renováveis',
  },
  {
    icon:<IconShield/>, color:'#9b59b6',
    title:'Rastreabilidade Total',
    desc:'Blockchain e RFID garantem a origem de cada produto — da semente ao prato — com transparência para consumidores e importadores.',
    tag:'Tecnologia & Confiança',
  },
];

function Praticas() {
  return (
    <section id="praticas" className="bg-dark1" style={{padding:'120px 0'}}>
      <div style={{maxWidth:1200,margin:'0 auto',padding:'0 24px'}}>
        <div style={{textAlign:'center',marginBottom:72}}>
          <div className="divider" style={{margin:'0 auto 20px'}}/>
          <h2 className="anim-fade-up" style={{fontSize:'clamp(28px,4vw,52px)',fontWeight:900,marginBottom:16,letterSpacing:'-1px'}}>
            Práticas que <span className="text-grad-verde">Transformam</span>
          </h2>
          <p className="anim-fade-up d1" style={{color:'rgba(245,240,232,.6)',maxWidth:520,margin:'0 auto',fontSize:16,lineHeight:1.7}}>
            Cada técnica abaixo une produtividade e responsabilidade ambiental — provando que é possível fazer mais produzindo melhor.
          </p>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))',gap:20}}>
          {praticas.map((p,i) => (
            <div key={p.title} className={`card-lift anim-fade-up d${i+1}`}
              style={{
                background:'rgba(255,255,255,.025)',borderRadius:12,padding:32,
                border:'1px solid rgba(255,255,255,.06)',position:'relative',overflow:'hidden',
              }}>
              <div style={{
                position:'absolute',top:0,right:0,width:100,height:100,
                background:`radial-gradient(circle at 100% 0%,${p.color}18,transparent 70%)`,
              }}/>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:20}}>
                <div style={{
                  width:48,height:48,color:p.color,padding:11,borderRadius:10,
                  background:`${p.color}18`,border:`1px solid ${p.color}30`,
                }}>{p.icon}</div>
                <span style={{
                  fontSize:10,letterSpacing:1.5,textTransform:'uppercase',
                  color:p.color,background:`${p.color}15`,
                  padding:'4px 10px',borderRadius:100,fontWeight:700,
                }}>{p.tag}</span>
              </div>
              <h3 style={{fontSize:20,fontWeight:800,marginBottom:10}}>{p.title}</h3>
              <p style={{color:'rgba(245,240,232,.6)',fontSize:14,lineHeight:1.7}}>{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Manifesto ──────────────────────────────────────────────── */
function Manifesto() {
  return (
    <section id="manifesto" style={{padding:'140px 0',position:'relative',overflow:'hidden'}}>
      {/* Full-bleed gradient bg */}
      <div style={{
        position:'absolute',inset:0,
        background:'linear-gradient(135deg,#0a1f0d 0%,#0d2410 40%,#0a1a0d 100%)',
        zIndex:0,
      }}/>
      {/* Decorative */}
      <div style={{position:'absolute',inset:0,overflow:'hidden',pointerEvents:'none'}}>
        {[...Array(3)].map((_,i) => (
          <div key={i} style={{
            position:'absolute',borderRadius:'50%',
            border:`1px solid rgba(126,184,63,${0.04+i*.02})`,
            width:`${400+i*200}px`,height:`${400+i*200}px`,
            top:'50%',left:'50%',
            transform:`translate(-50%,-50%)`,
          }}/>
        ))}
      </div>

      <div style={{maxWidth:900,margin:'0 auto',padding:'0 24px',textAlign:'center',position:'relative',zIndex:1}}>
        <div className="anim-fade-up" style={{
          display:'inline-flex',alignItems:'center',gap:10,marginBottom:32,
          border:'1px solid rgba(201,162,39,.4)',borderRadius:100,padding:'8px 20px',
        }}>
          <div style={{width:8,height:8,borderRadius:'50%',background:'#c9a227'}} className="anim-glow"/>
          <span style={{fontSize:11,letterSpacing:3,textTransform:'uppercase',color:'#c9a227',fontWeight:700}}>
            Nosso Manifesto
          </span>
        </div>

        <h2 className="anim-fade-up d1" style={{
          fontSize:'clamp(28px,5vw,64px)',fontWeight:900,lineHeight:1.1,
          marginBottom:32,letterSpacing:'-1.5px',
        }}>
          O Campo Não Escolhe
          <br/>
          <span className="text-grad-verde">Entre Produzir</span>
          <br/>
          <span style={{color:'rgba(245,240,232,.9)'}}>e </span>
          <span className="text-grad-gold">Preservar</span>
        </h2>

        <p className="anim-fade-up d2" style={{
          fontSize:'clamp(16px,2vw,20px)',lineHeight:1.85,color:'rgba(245,240,232,.72)',
          maxWidth:680,margin:'0 auto 48px',
        }}>
          Acreditamos que o agricultor brasileiro é o maior guardião do meio ambiente do planeta.
          É no campo que nascem a comida, a água limpa e o ar puro que sustentam as cidades.
          <br/><br/>
          <strong style={{color:'#a8d55a'}}>Produzir com consciência não é fraqueza — é a força de quem pensa no amanhã.</strong>{' '}
          É a convicção de que terra cuidada produz por gerações. De que floresta e lavoura não são opostos — são parceiros.
          <br/><br/>
          O futuro do agro é verde, forte e sustentável. E ele já começou.
        </p>

        {/* Highlight pills */}
        <div className="anim-fade-up d3" style={{display:'flex',flexWrap:'wrap',gap:12,justifyContent:'center',marginBottom:56}}>
          {['Terra Viva','Água Limpa','Ar Puro','Comida Real','Geração Futura','Agro Consciente'].map(tag => (
            <span key={tag} style={{
              padding:'8px 18px',borderRadius:100,fontSize:13,fontWeight:700,
              border:'1px solid rgba(126,184,63,.3)',color:'rgba(245,240,232,.8)',
              letterSpacing:.5,
            }}>{tag}</span>
          ))}
        </div>

        <div className="anim-fade-up d4">
          <a href="#contato" className="btn-verde" style={{fontSize:15,padding:'16px 44px'}}
            onClick={e=>{e.preventDefault();document.getElementById('contato')?.scrollIntoView({behavior:'smooth'})}}>
            Faça Parte do Movimento <IconArrow/>
          </a>
        </div>
      </div>
    </section>
  );
}

/* ─── Contato / CTA ────────────────────────────────────────────── */
function Contato() {
  const [form, setForm] = useState({nome:'',email:'',mensagem:''});
  const [sent, setSent] = useState(false);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(form.nome && form.email) setSent(true);
  };
  const inputStyle: React.CSSProperties = {
    width:'100%',background:'rgba(255,255,255,.05)',border:'1px solid rgba(126,184,63,.2)',
    borderRadius:6,padding:'14px 16px',color:'#f5f0e8',fontSize:15,outline:'none',
    transition:'border-color .2s',fontFamily:'inherit',
  };
  return (
    <section id="contato" className="bg-dark2" style={{padding:'120px 0'}}>
      <div style={{maxWidth:1200,margin:'0 auto',padding:'0 24px'}}>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:80,alignItems:'start'}} className="contato-grid">
          {/* Left */}
          <div className="anim-slide-l">
            <div className="divider" style={{marginBottom:24}}/>
            <h2 style={{fontSize:'clamp(28px,4vw,48px)',fontWeight:900,marginBottom:20,letterSpacing:'-1px'}}>
              Junte-se ao{' '}
              <span className="text-grad-verde">Movimento</span>
            </h2>
            <p style={{color:'rgba(245,240,232,.65)',fontSize:16,lineHeight:1.8,marginBottom:36}}>
              Seja produtor rural, pesquisador, investidor ou consumidor consciente —
              o futuro sustentável do campo precisa de você.
            </p>
            {[
              {t:'Produtores Rurais', d:'Compartilhe suas boas práticas e inspire outros agricultores.'},
              {t:'Pesquisadores & Técnicos', d:'Conecte inovação à realidade do campo brasileiro.'},
              {t:'Consumidores Conscientes', d:'Valorize quem produz com responsabilidade ambiental.'},
            ].map(it => (
              <div key={it.t} style={{
                display:'flex',gap:16,marginBottom:24,padding:20,
                background:'rgba(126,184,63,.05)',borderRadius:10,
                border:'1px solid rgba(126,184,63,.1)',
              }}>
                <div style={{color:'#7eb83f',marginTop:2,flexShrink:0}}><IconCheck/></div>
                <div>
                  <div style={{fontWeight:700,marginBottom:4}}>{it.t}</div>
                  <div style={{color:'rgba(245,240,232,.55)',fontSize:13,lineHeight:1.6}}>{it.d}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Right - Form */}
          <div className="anim-slide-r" style={{
            background:'rgba(255,255,255,.03)',borderRadius:16,padding:40,
            border:'1px solid rgba(126,184,63,.12)',
          }}>
            {sent ? (
              <div style={{textAlign:'center',padding:'40px 0'}}>
                <div style={{fontSize:56,marginBottom:16}}>🌱</div>
                <h3 style={{fontSize:24,fontWeight:800,color:'#7eb83f',marginBottom:12}}>Mensagem Enviada!</h3>
                <p style={{color:'rgba(245,240,232,.65)',lineHeight:1.7}}>
                  Obrigado por fazer parte do movimento agro sustentável.<br/>
                  Entraremos em contato em breve.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{display:'flex',flexDirection:'column',gap:18}}>
                <h3 style={{fontSize:22,fontWeight:800,marginBottom:4}}>Fale Conosco</h3>
                <p style={{color:'rgba(245,240,232,.55)',fontSize:14,marginBottom:8}}>Envie sua mensagem ou proposta</p>
                <div>
                  <label style={{fontSize:12,letterSpacing:1,textTransform:'uppercase',color:'rgba(245,240,232,.5)',fontWeight:700,display:'block',marginBottom:8}}>Nome *</label>
                  <input
                    style={inputStyle}
                    placeholder="Seu nome completo"
                    value={form.nome}
                    onChange={e => setForm({...form,nome:e.target.value})}
                    onFocus={e=>(e.target.style.borderColor='#7eb83f')}
                    onBlur={e=>(e.target.style.borderColor='rgba(126,184,63,.2)')}
                    required
                  />
                </div>
                <div>
                  <label style={{fontSize:12,letterSpacing:1,textTransform:'uppercase',color:'rgba(245,240,232,.5)',fontWeight:700,display:'block',marginBottom:8}}>E-mail *</label>
                  <input
                    type="email" style={inputStyle}
                    placeholder="seu@email.com.br"
                    value={form.email}
                    onChange={e => setForm({...form,email:e.target.value})}
                    onFocus={e=>(e.target.style.borderColor='#7eb83f')}
                    onBlur={e=>(e.target.style.borderColor='rgba(126,184,63,.2)')}
                    required
                  />
                </div>
                <div>
                  <label style={{fontSize:12,letterSpacing:1,textTransform:'uppercase',color:'rgba(245,240,232,.5)',fontWeight:700,display:'block',marginBottom:8}}>Mensagem</label>
                  <textarea
                    style={{...inputStyle,resize:'vertical',minHeight:110}}
                    placeholder="Conte-nos sobre sua propriedade, projeto ou ideia..."
                    value={form.mensagem}
                    onChange={e => setForm({...form,mensagem:e.target.value})}
                    onFocus={e=>(e.target.style.borderColor='#7eb83f')}
                    onBlur={e=>(e.target.style.borderColor='rgba(126,184,63,.2)')}
                  />
                </div>
                <button type="submit" className="btn-verde" style={{width:'100%',textAlign:'center',padding:'15px'}}>
                  Enviar Mensagem
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
      <style>{`
        @media (max-width:768px) { .contato-grid { grid-template-columns:1fr !important; gap:40px !important; } }
      `}</style>
    </section>
  );
}

/* ─── Footer ──────────────────────────────────────────────────── */
function Footer() {
  return (
    <footer style={{
      background:'#0a0f0b',borderTop:'1px solid rgba(126,184,63,.1)',
      padding:'60px 0 32px',
    }}>
      <div style={{maxWidth:1200,margin:'0 auto',padding:'0 24px'}}>
        <div style={{display:'grid',gridTemplateColumns:'2fr 1fr 1fr',gap:48,marginBottom:48}} className="footer-grid">
          <div>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:16}}>
              <div style={{width:36,height:36,background:'linear-gradient(135deg,#1a5c2a,#7eb83f)',borderRadius:6,padding:8,color:'#f5f0e8'}}>
                <IconLeaf/>
              </div>
              <span style={{fontWeight:900,fontSize:18,letterSpacing:2}}>
                <span className="text-grad-verde">AGRO</span>
                <span style={{color:'#f5f0e8'}}> FORTE</span>
              </span>
            </div>
            <p style={{color:'rgba(245,240,232,.5)',fontSize:14,lineHeight:1.8,maxWidth:300}}>
              Conectando o poder do campo brasileiro com a responsabilidade de cuidar do planeta para as próximas gerações.
            </p>
          </div>
          <div>
            <div style={{fontSize:12,letterSpacing:2,textTransform:'uppercase',color:'#7eb83f',fontWeight:700,marginBottom:16}}>Navegação</div>
            {['Início','Pilares','Dados','Práticas','Manifesto','Contato'].map(l => (
              <div key={l} style={{marginBottom:10}}>
                <a href="#" style={{color:'rgba(245,240,232,.5)',fontSize:14,textDecoration:'none',transition:'color .2s'}}
                  onMouseEnter={e=>(e.currentTarget.style.color='#7eb83f')}
                  onMouseLeave={e=>(e.currentTarget.style.color='rgba(245,240,232,.5)')}
                >{l}</a>
              </div>
            ))}
          </div>
          <div>
            <div style={{fontSize:12,letterSpacing:2,textTransform:'uppercase',color:'#7eb83f',fontWeight:700,marginBottom:16}}>Princípios</div>
            {['Alta Produtividade','Sustentabilidade','Tecnologia Verde','Código Florestal','ESG Rural','Rastreabilidade'].map(l => (
              <div key={l} style={{marginBottom:10,color:'rgba(245,240,232,.5)',fontSize:14}}>{l}</div>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div style={{
          borderTop:'1px solid rgba(126,184,63,.08)',paddingTop:28,
          display:'flex',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap',gap:16,
        }}>
          <p style={{color:'rgba(245,240,232,.35)',fontSize:13}}>
            © 2025 Agro Forte · Futuro Sustentável · Feito com 🌱 para o Campo Brasileiro
          </p>
          <div style={{display:'flex',gap:8}}>
            {['Terra','Água','Ar'].map(el => (
              <span key={el} style={{
                fontSize:11,padding:'4px 12px',borderRadius:100,
                border:'1px solid rgba(126,184,63,.2)',color:'rgba(126,184,63,.6)',letterSpacing:1,
              }}>{el}</span>
            ))}
          </div>
        </div>
      </div>
      <style>{`
        @media (max-width:768px) { .footer-grid { grid-template-columns:1fr !important; gap:32px !important; } }
      `}</style>
    </footer>
  );
}

/* ─── App ────────────────────────────────────────────────────── */
export default function App() {
  return (
    <>
      <Navbar/>
      <Hero/>
      <Pilares/>
      <Dados/>
      <Praticas/>
      <Manifesto/>
      <Contato/>
      <Footer/>
    </>
  );
}
